package com.bmp.saviya.auth.repository;

import com.bmp.saviya.auth.model.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role, Long>{
}
